#include <stdio.h>

int main(){
    float a1, b2, pe, su;
    printf("Ingrese el valor del lado a ");
    scanf("%f", &a1);
    printf("Ingrese el valor del lado b ");
    scanf("%f", &b2);
    pe= a1+a1+b2+b2;
    su= a1*b2;
    printf("El valor del perimetro es de: %f\nEl valor de la superficie es de: %f", pe, su);
}