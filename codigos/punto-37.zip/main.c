#include <stdio.h>

int main()
{
    char C1, C2, C3;
    printf("Ingrese su primer caracter\n");
    scanf(" %c", &C1);
    printf("Ingrese su segundo caracter\n");
    scanf(" %c", &C2);
    printf("Ingrese su tercer caracter\n");
    scanf(" %c", &C3);

    if(C1 < C2 && C2 < C3){
        printf("Su orden es: %c,%c,%c", C1, C2, C3);
    }else if(C1 < C3 && C3 < C2){
        printf("Su orden es: %c,%c,%c", C1, C3, C2);
    }else if(C2 < C1 && C1 < C3){
        printf("Su orden es: %c,%c,%c", C2, C1, C3);
    }else if(C2 < C3 && C3 < C1){
        printf("Su orden es: %c,%c,%c", C2, C3, C1);
    }else if(C3 < C1 && C1 < C2){
        printf("Su orden es: %c,%c,%c", C3, C1, C2);
    }else if(C3 < C2 && C2 < C1){
        printf("Su orden es: %c,%c,%c", C3, C2, C1);
    }else{
        printf("Los caracteres no están en orden");
    }

    return 0;
}