#include <stdio.h>

int main(){
    float kl, pc, pp;
    printf("Ingrese el valor del precio por kilogramo: ");
    scanf("%f", &pc);
    printf("Ingrese la cantidad de kilogramos a comprar: ");
    scanf("%f", &kl);
    pp= kl*pc;
printf("El monto que usted debe pagar es de: %f", pp);
}