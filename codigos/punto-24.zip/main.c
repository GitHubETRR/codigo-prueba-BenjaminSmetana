#include <stdio.h>

int main(){
    float h, r, a, v;
    printf("Ingrese el valor de la altura del cilindro: ");
    scanf("%f",&h);
    printf("Ingrese el valor del radio del cilindro: ");
    scanf("%f",&r);
    a=(2*(3.14*(r+r))) + 2*(3.14*r*h);
    v=3.14*(r+r)*h;
    printf("El valor del area del cilindro es: %f\n", a);
    printf("El valor del volumen del cilindro es: %f", v);
}