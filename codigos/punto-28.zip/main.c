#include <stdio.h>
#include <math.h>

int main()
{
  float a, b, c, r1, r2;
  printf("Ingrese el valor de 'a' ");
  scanf("%f", &a);
  printf("Ingrese el valor de 'b' ");
  scanf("%f", &b);
  printf("Ingrese el valor de 'c' ");
  scanf("%f", &c);
  r1=(-b+sqrt(b*b-4*a*c))/(2*a);
  printf("Su primera raíz es: %f\n", r1);
  r2=(-b-sqrt(b*b-4*a*c))/(2*a);
  printf("Su segunda raíz es: %f", r2);
}
