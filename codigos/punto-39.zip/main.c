#include <math.h>
#include <stdio.h>

int main()
{
    int nota;
    printf("Ingrese su nota: \n");
    scanf("%d", &nota);
    if(nota==10){
        printf("El alumno obtuvo un sobresaliente");
    
    }else if(nota==9 || nota==8){
        printf("El alumno obtuvo un distinguido");
    }else if(nota==7 || nota==6){
        printf("El alumno obtuvo un bueno");
    }else if(nota==5){
        printf("El alumno obtuvo un aprobado");
    }else if(nota<5){
        printf("El alumno obtuvo un reprobado");
    }else{ 
        printf("Nota no válida");
    }
    return 0;
}
