#include <stdio.h>

int main() {
    int viajecorto, kilos, precio;
    printf("Ingrese un 1 si su viaje es de corta distancia, de lo contrario presione cualquier otro número\n");
    scanf("%d", &viajecorto);

    if (viajecorto == 1) {
        printf("Ingrese la cantidad de peso que desea llevar (en kilos):\n ");
        scanf("%d", &kilos);

        if (kilos > 20) {
            precio = 1500 + (kilos - 20) * 800;
            printf("El precio de su viaje será de %d$", precio);
        } else {
            precio = 1500;
            printf("El precio de su viaje será de %d$", precio);
        }
    } else {
        printf("Ingrese la cantidad de peso que desea llevar (en kilos):\n ");
        scanf("%d", &kilos);

        if (kilos > 20) {
            if ((kilos - 20) % 5 >= 5) {
                precio = 2000 + (((kilos - 20) / 5) * 800);
            } else {
                precio = 2000 + (((kilos - 20) / 5) * 800);
            }
            printf("El precio de su viaje será de %d$", precio);
        } else {
            precio = 2000;
            printf("El precio de su viaje será de %d$", precio);
        }
    }

    return 0;
}