#include <stdio.h>

int main(){
    int seg, sres, min, hor;
    printf("Ingrese la cantidad de segundos:\n");
    scanf("%d",&seg);
    if (seg<=86400){
    hor=seg/3600;
    min=(seg%3600)/60;
    sres=seg%60;
    printf("El tiempo en horas, minutos y segundos es de %d:%d:%d", hor, min, sres);
    }else{
        printf("Ingrese una cantidad de segundor menor o igual a 86400");
        return(0);
    }
}