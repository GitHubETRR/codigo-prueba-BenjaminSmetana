#include <stdio.h>

int main(){
    float a1, b2, c3;
    printf("Ingrese el valor del primer angulo: ");
    scanf("%f" ,&a1);
    printf("Ingrese el valor del segundo angulo: ");
    scanf("%f", &b2);
    c3=180-a1-b2;
    printf("El valor del angulo que falta es de: %f", c3);
}