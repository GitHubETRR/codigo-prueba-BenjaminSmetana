#include <stdio.h>

int main(){
    int anios, dias; 
    printf("Ingrese su edad en años ");
    scanf("%d", &anios);
    dias= anios*365;
    printf("La cantidad de días que usted lleva viviendo son: %d", dias);

}
