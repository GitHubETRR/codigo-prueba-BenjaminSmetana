#include <stdio.h>

int main(){
int número, ultcifra;
printf("Ingrese un número de dos cifras o más: \n");
scanf("%d", &número);
if (número>9)
{
    ultcifra=número%10;
    printf("La última cifra de su número es: %d", ultcifra);
}
else{
    return 0;
}
}