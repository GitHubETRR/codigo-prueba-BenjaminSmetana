#include <stdio.h>

int main(){
    int numero, cifra1, cifra2, cifra3;
    printf("Ingrese el numero que desea mostrar sus cifras: ");
    scanf("%d",&numero);
    if (numero < 100 || numero > 999) {
        printf("Por favor, introduce un numero de tres cifras.\n");
        return 0;
    }else{
    cifra1=numero/100;
    cifra2=(numero/10)%10;
    cifra3=numero%10;
    printf("Su primer cifra es: %d\n", cifra1);
    printf("Su segunda cifra es: %d\n", cifra2);
    printf("Su tercera cifra es: %d", cifra3);
    }
}
