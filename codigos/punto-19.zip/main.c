#include <stdio.h>
#include <math.h>

int main(){
    float a1, b2, h3;
    printf("Ingrese el valor de los catetos\n" );
    printf("Cateto A: ");
    scanf("%f", &a1);
    printf("Cateto B: ");
    scanf("%f", &b2);
    h3=sqrt(a1*a1+b2*b2);
    printf("La hipotenusa de su triangulo tiene el valor de: %f", &h3);
    
}