#include <stdio.h>

int main(){
    float far, cel;
    printf("Ingrese los grados en Celsius:\n");
    scanf("%f", &cel);
    far=cel*1.8+32;
    printf("Su valor en grados Fahrenheit es de %f", &far);

}