#include <stdio.h>
#include <math.h>

int main(){
    float rad, ar;
    printf("Ingrese el valor del radio: ");
    scanf("%f",&rad);
    ar=3.14*rad*rad;
    printf("El valor del area del circulo es de: %f", ar);

}