#include <stdio.h>
#include <math.h>

int main(){
    float a1, b2, c3, s, ar;
    printf("Ingrese el valor de los lados\n");
    printf("Lado a: ");
    scanf("%f", &a1);
    printf("Lado b: ");
    scanf("%f", &b2);
    printf("Lado c: ");
    scanf("%f", &c3);
    s=(a1+b2+c3)/2;
    ar=sqrt(s*(s-a1)*(s-b2)*(s-c3));
    printf("El valor del area de este triangulo es de %f", ar);
    
}