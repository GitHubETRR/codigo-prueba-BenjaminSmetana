
#include <stdio.h>
#include <math.h>

int main(){
    float n1, n2, p, r;
    printf("Si desea dividir ingrese 1, multiplicar ingrese 2, sumar ingrese 3 y restar ingrese 4\n");
    scanf("%f",&p);
    if (p==3){
    printf("Ingrese los dos números que desea sumar\n");
    printf("Primer número: ");
    scanf("%f",&n1);
    printf("Segundo número: ");
    scanf("%f",&n2);
    r=n1+n2;
    printf("El resultado de la suma es: %f", r);
    }
    else if (p==2){
    printf("Ingrese los dos números que desea multiplicar\n");
    printf("Primer número: ");
    scanf("%f",&n1);
    printf("Segundo número: ");
    scanf("%f",&n2);
    r=n1*n2;
    printf("El resultado de la multiplicacion es: %f", r);
    }
else if (p==1){
    printf("Ingrese los dos números que desea dividir\n");
    printf("Primer número: ");
    scanf("%f",&n1);
    printf("Segundo número: ");
    scanf("%f",&n2);
    if(n2==0){
        printf("ERROR MATH");
        return 0;
        }else{
            r=n1/n2;
            printf("El resultado de la division es: %f", r);
        }
    }
    else if (p==4){
    printf("Ingrese los dos números que desea restar\n");
    printf("Primer número: ");
    scanf("%f",&n1);
    printf("Segundo número: ");
    scanf("%f",&n2);
    r=n1-n2;
    printf("El resultado de la resta es: %f", r);
    }else{
        printf("Ingrese una operacion correcta");
        return(0);
    }
}

