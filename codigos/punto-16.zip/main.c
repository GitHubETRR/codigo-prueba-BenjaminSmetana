#include <stdio.h>
#include <math.h>

int main(){
    float su, l, pe;
    printf("Ingrese el valor de la superficie: ");
    scanf("%f", &su);
    l=sqrt(su);
    //sqrt la utilizo para indicar que es la raiz cuadrada
    pe= l*4;
    printf("El valor del perímetro es de: %f", pe);
    
}
