#include <stdio.h>
#include <math.h>

int main(){
    float h, a, p, sn;
    printf("Ingrese la cantidad de horas trabajadas: ");
    scanf("%f",&h);
    printf("Ingrese la antiguedad en años: ");
    scanf("%f",&a);
    p=(4500*2)/100;
    sn=(4500*h)+(a*p);
    printf("El valor de su sueldo neto es de: %f", sn);

    
}
