#include <stdio.h>

int main(){
    float cm;
    int vp, vl;
    printf("Ingrese el valor en centimetros: ");
    scanf("%f",&cm);
    vp=cm/30.48;
    vl=cm/2.54;
    printf("Su valor en píes: %d\nSu valor en pulgadas: %d", vp, vl);

}
